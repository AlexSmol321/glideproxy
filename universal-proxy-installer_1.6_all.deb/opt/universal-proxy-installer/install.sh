#!/bin/bash
echo "Universal Proxy Installer v1.6 — установка"

read -p "Введите домен прокси (proxy.example.com): " proxy_domain
read -p "Введите целевой домен (target.example.com): " target_domain
read -p "Email для Let's Encrypt: " email
read -p "Имя проекта [default: reverse-proxy]: " project_name
project_name=${project_name:-reverse-proxy}
project_dir="/opt/$project_name"

echo "[INFO] Укрепление безопасности (v1.6) — начало..."

# Создание пользователя
if ! id "proxyuser" &>/dev/null; then
    useradd -r -s /bin/false proxyuser
    echo "[INFO] Пользователь proxyuser создан."
fi

# Клонирование репозитория
if [ ! -d "$project_dir" ]; then
    echo "[INFO] Клонируем проект в $project_dir..."
    git clone https://github.com/AlexSmol321/glideproxy "$project_dir"
fi

chown -R proxyuser:proxyuser "$project_dir"

# Установка зависимостей
apt update
apt install -y nginx certbot nodejs npm ufw curl git

cd "$project_dir"
npm install

# PM2 запуск
npm install -g pm2
pm2 start src/app.js --name "$project_name"
pm2 save

echo "[✅] Установка завершена. Прокси доступен по адресу: https://$proxy_domain"
