#!/bin/bash
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
read -p "Proxy domain (e.g. proxy.example.com): " PROXY_DOMAIN
read -p "Target domain (e.g. target.example.com): " TARGET_DOMAIN
read -p "SSL email for Let's Encrypt: " SSL_EMAIL
read -p "Project name [reverse-proxy]: " PROJECT_NAME
PROJECT_NAME=${PROJECT_NAME:-reverse-proxy}
PROJECT_DIR="/opt/$PROJECT_NAME"

log_info "Installing dependencies..."
apt-get update -y && apt-get install -y nginx nodejs npm git certbot python3-certbot-nginx fail2ban

log_info "Cloning reverse proxy repo..."
git clone https://github.com/AlexSmol321/glideproxy.git "$PROJECT_DIR"

log_info "Creating system user..."
useradd -r -s /usr/sbin/nologin proxyuser || true
chown -R proxyuser:proxyuser "$PROJECT_DIR"

log_info "Installing npm dependencies..."
cd "$PROJECT_DIR"
sudo -u proxyuser npm install
sudo -u proxyuser npm install http-proxy-middleware@2.0.9 --save

log_info "Setting up nginx config..."
cat > /etc/nginx/sites-available/$PROJECT_NAME <<EOF
server {
    listen 80;
    server_name $PROXY_DOMAIN;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
EOF
ln -s /etc/nginx/sites-available/$PROJECT_NAME /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

log_info "Setting up SSL via certbot..."
certbot --nginx --non-interactive --agree-tos --email $SSL_EMAIL -d $PROXY_DOMAIN
systemctl enable certbot.timer && systemctl start certbot.timer

log_info "Setting up PM2 process..."
npm install pm2@5.3.0 -g
sudo -u proxyuser pm2 start ecosystem.config.js --env production
sudo -u proxyuser pm2 save
sudo -u proxyuser pm2 startup systemd -u proxyuser --hp /home/proxyuser
systemctl enable pm2-proxyuser || true

log_info "Installing Fail2Ban rules..."
cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
cat >> /etc/fail2ban/jail.local <<EOFF
[nginx-http-auth]
enabled = true
[nginx-botsearch]
enabled = true
[nginx-limit-req]
enabled = true
EOFF
systemctl restart fail2ban
systemctl enable fail2ban

log_success "Universal proxy installed successfully at https://$PROXY_DOMAIN"
